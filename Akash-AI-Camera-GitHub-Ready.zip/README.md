# Akash AI Camera

Fast Android computational-photography camera.

## Current features
- CameraX camera preview
- Low-latency JPEG capture
- On-device color/contrast enhancement
- Mild sharpening
- Automatic gallery save
- No cloud upload required

## Open in Android Studio
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect an Android phone with USB debugging enabled.
4. Run the app.

## GitHub
Create a repository named `Akash-AI-Camera`, then upload this project folder.

## Next upgrade
Replace `AiEnhancer` with a TensorFlow Lite / MediaPipe enhancement model for stronger AI denoise, HDR reconstruction, portrait enhancement and super-resolution.
