package com.akash.aicamera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var captureButton: Button
    private lateinit var enhancing: TextView
    private var imageCapture: ImageCapture? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        captureButton = findViewById(R.id.captureButton)
        enhancing = findViewById(R.id.enhancing)

        captureButton.setOnClickListener { takePhoto() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()

            val preview = Preview.Builder().build().also {
                it.surfaceProvider = previewView.surfaceProvider
            }

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .setJpegQuality(95)
                .build()

            provider.unbindAll()
            provider.bindToLifecycle(
                this,
                CameraSelector.DEFAULT_BACK_CAMERA,
                preview,
                imageCapture
            )
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return

        val photoFile = File.createTempFile("akash_ai_", ".jpg", cacheDir)
        val options = ImageCapture.OutputFileOptions.Builder(photoFile).build()

        captureButton.isEnabled = false
        enhancing.visibility = View.VISIBLE

        capture.takePicture(
            options,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    CoroutineScope(Dispatchers.Default).launch {
                        val source = BitmapFactory.decodeFile(photoFile.absolutePath)
                        val enhanced = source?.let { AiEnhancer.enhance(it) }

                        if (enhanced != null) {
                            saveToGallery(enhanced)
                        }

                        withContext(Dispatchers.Main) {
                            enhancing.visibility = View.GONE
                            captureButton.isEnabled = true
                            photoFile.delete()
                        }
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    enhancing.visibility = View.GONE
                    captureButton.isEnabled = true
                }
            }
        )
    }

    private fun saveToGallery(bitmap: Bitmap) {
        val name = "AkashAI_" +
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Akash AI Camera")
        }

        val uri = contentResolver.insert(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            values
        ) ?: return

        contentResolver.openOutputStream(uri)?.use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
        }
    }
}

object AiEnhancer {
    fun enhance(input: Bitmap): Bitmap {
        // Fast computational-photography style enhancement.
        // This is intentionally on-device and dependency-light.
        val src = input.copy(Bitmap.Config.ARGB_8888, false)
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            // Slight contrast boost + saturation boost.
            val matrix = android.graphics.ColorMatrix().apply {
                setSaturation(1.16f)
                val contrast = 1.10f
                val translate = (-0.5f * contrast + 0.5f) * 255f
                postConcat(android.graphics.ColorMatrix(floatArrayOf(
                    contrast,0f,0f,0f,translate,
                    0f,contrast,0f,0f,translate,
                    0f,0f,contrast,0f,translate,
                    0f,0f,0f,1f,0f
                )))
            }
            colorFilter = android.graphics.ColorMatrixColorFilter(matrix)
        }

        canvas.drawBitmap(src, null, Rect(0, 0, out.width, out.height), paint)

        // Mild unsharp mask approximation for crispness.
        return sharpen(out)
    }

    private fun sharpen(bitmap: Bitmap): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        val result = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        fun lum(c: Int): Int =
            (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)).toInt()

        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                val center = pixels[i]
                val avg = (
                    lum(pixels[i - 1]) + lum(pixels[i + 1]) +
                    lum(pixels[i - w]) + lum(pixels[i + w])
                ) / 4

                val detail = lum(center) - avg
                val amount = 0.28f
                val r = (Color.red(center) + detail * amount).toInt().coerceIn(0,255)
                val g = (Color.green(center) + detail * amount).toInt().coerceIn(0,255)
                val b = (Color.blue(center) + detail * amount).toInt().coerceIn(0,255)

                pixels[i] = Color.argb(Color.alpha(center), r, g, b)
            }
        }
        result.setPixels(pixels, 0, w, 0, 0, w, h)
        return result
    }
}
